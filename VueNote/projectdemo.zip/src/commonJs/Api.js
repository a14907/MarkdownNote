import axios from "axios"
import qs from "qs"
import urlDict from "../assets/json/urlDict"
import { isIntersection } from "./arrayTools"
import { log } from "./debug"
import { message } from "./message"

class Api {
    constructor(checkStatus) {
        this.config = {}
        this.baseURL = urlDict.api根地址
        this.appVm = null
        this.currentVm = null
        this.timeout = 8000
        this.checkStatus = checkStatus(this)
    }

    /**
     * 注入vm实例，以便显示弹窗等等
     *
     * @param {*} vm
     * @memberof Api
     */
    dependencyInjection(vm) {
        this.appVm = vm
        log("注入vm")
    }

    unInjection() {
        this.appVm = null
    }

    errorProcessor(vm, error) {
        let msg = ""
        if (error.response == null) {
            msg = "网络异常"
        } else if (error.response.status == null) {
            msg = "未知的错误"
        } else if (error.response.status + "" === "404") {
            msg = "资源不存在"
        } else if (error.response.status > 305 || error.response.status < 200) {
            msg = error.response.statusText + error.response.status
        }
        message(vm, msg)
        throw new Error("请求失败", msg)
    }

    /**
     * 请求拦截器设置
     *
     * @memberof Api
     */
    interceptorsRegister() {
        axios.interceptors.request.use(
            config => config,
            error => Promise.reject(error)
        )

        axios.interceptors.response.use(
            response => response,
            error => this.errorProcessor(this.appVm, error)
        )
    }

    post(url, data) {
        let result = axios({
            method: "post",
            baseURL: this.baseURL,
            url,
            data: qs.stringify(data),
            timeout: this.timeout,
            headers: {
                "X-Requested-With": "XMLHttpRequest",
                "Content-Type":
                    "application/x-www-form-urlencoded; charset=UTF-8"
            }
        }).then(response => this.checkStatus(response))
        return result
    }

    get(url, params) {
        let result = axios({
            method: "get",
            baseURL: this.baseURL,
            url,
            params,
            timeout: this.timeout,
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        }).then(response => this.checkStatus(response))
        return result
    }
}

const checkSuccess = function(response, vm) {
    let success = response.data.success
    if (success === true) {
        return response
    } else {
        let msg = response.data.error.message
        message(vm, msg)
        throw new Error("服务器返回报错，拦截程序运行")
    }
}

const checkStatus = function(_this) {
    let result = function(response) {
        let vm = _this.appVm
        let result = {
            status: -404,
            msg: "未知的异常"
        }
        checkSuccess(response, vm)
        let statusList = [200, 304, 400]
        if (response && isIntersection(response.status, ...statusList)) {
            result = response.data
            result["status"] = response.status
            return result
        }
        return result
    }
    return result
}

const api = new Api(checkStatus)
api.interceptorsRegister()

export const Get = function(url, loadingModel, params = {}) {
    if (typeof params === "string") {
        throw new Error("get参数必须是一个对象")
    }
    log("请求的地址是:", url)
    let result = api.get(url, params)
    setTimeout(() => {
        if (loadingModel == null) return
        result
            .catch(loadingModel.setErrorDict)
            .finally(loadingModel.closeAllLoading)
    }, 0)
    return result
}

export const Post = function(url, loadingModel, params = {}) {
    let result = api.post(url, params)
    log("请求的地址是:", url)
    setTimeout(() => {
        if (loadingModel == null) return
        result
            .catch(loadingModel.setErrorDict)
            .finally(loadingModel.closeAllLoading)
    }, 0)
    return result
}
