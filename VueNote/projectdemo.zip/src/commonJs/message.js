export const message = function(vm, msg) {
    vm.$notify.open({
        content: msg,
        type: "danger",
        duration: 1500,
        placement: "top-center"
    })
}
