/**
 * 打印函数-console.log
 *
 * @param {...Array<any>} args
 */
export const log = function(...args) {
    console.log(...args)
}
