class UrlDict {
    constructor() {
        this.api根地址 = ''
    }
}
const urlDict = new UrlDict()
export default urlDict
