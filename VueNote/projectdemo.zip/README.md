# 后台管理系统前端项目说明

> zhihu pro

## 生成命令

```bash
# 安装依赖
npm install
yarn

# 运行调试，默认地址 localhost:8080
npm run dev

# 项目打包
npm run build

# 生成一个构建报告
npm run build --report
```

## 整体知识体系

### 第三方库

- `axios` api 请求库 `yarn add axios`
- `es6-promise` 使一些浏览器支持 promise
- `promise.prototype.finally `  解决部分浏览器没有finally 函数
- `vue-lazyload` 图片懒加载
- `vue-loading-template` loading的组件
- `vue-localstorage` 控制缓存库


### 库的使用方法

```javascript
// 在main.js文件里
// es6-promise
import Promise from 'es6-promise'
Promise.polyfill()

// promise.prototype.finally
import promiseFinally from 'promise.prototype.finally'
promiseFinally.shim()


// vue-loading-template
import VueLoading from 'vue-loading-template'
Vue.use(VueLoading /** options **/)

// vue-lazyload
import VueLazyload from 'vue-lazyload'
Vue.use(VueLazyload, {
    preLoad: 1.3,
    error: 'static/error.png',
    loading: 'static/loading.gif',
    attempt: 1
})
```





### css 预处理器

- SCSS
  - 一个 ruby 写的玩意，功能很强大，基本上可以认为是第一个 css 的编程语言了。


  - 安装方法

    ```bash
    yarn add node-sass
    yarn add sass-loader 
    ```
